// ============================================
// 🎵 Discord Music Bot
// ============================================
// Commands:
//   !play <ชื่อเพลง / YouTube URL>  - เล่นเพลง / เพิ่มเข้าคิว
//   !skip                            - ข้ามเพลง
//   !stop                            - หยุดเล่นและออกจากห้อง
//   !queue                           - ดูคิวเพลง
//   !pause                           - หยุดชั่วคราว
//   !resume                          - เล่นต่อ
//   !np                              - เพลงที่กำลังเล่นอยู่
//   !volume <0-100>                  - ปรับเสียง
//   !help                            - ดูคำสั่งทั้งหมด
// ============================================

const { Client, GatewayIntentBits, EmbedBuilder } = require("discord.js");
const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  entersState,
} = require("@discordjs/voice");
const play = require("play-dl");

// ---------- Config ----------
const TOKEN = process.env.DISCORD_TOKEN; // ใส่ Token ใน .env หรือ environment variable
const PREFIX = "!";

// ---------- Bot Setup ----------
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.MessageContent,
  ],
});

// เก็บข้อมูลเพลงแต่ละ server (guild)
const queues = new Map();

// ---------- Helper: สร้าง/ดึง queue ของ guild ----------
function getQueue(guildId) {
  if (!queues.has(guildId)) {
    queues.set(guildId, {
      songs: [],
      player: null,
      connection: null,
      volume: 50,
      playing: false,
      textChannel: null,
    });
  }
  return queues.get(guildId);
}

// ---------- Helper: Embed สวยๆ ----------
function songEmbed(title, description, color = 0x5865f2) {
  return new EmbedBuilder()
    .setTitle(title)
    .setDescription(description)
    .setColor(color)
    .setTimestamp();
}

// ---------- เล่นเพลงถัดไปในคิว ----------
async function playSong(guild, queue) {
  if (queue.songs.length === 0) {
    queue.playing = false;
    if (queue.connection) {
      queue.connection.destroy();
      queue.connection = null;
    }
    queues.delete(guild.id);
    return;
  }

  const song = queue.songs[0];
  queue.playing = true;

  try {
    const stream = await play.stream(song.url);
    const resource = createAudioResource(stream.stream, {
      inputType: stream.type,
      inlineVolume: true,
    });
    resource.volume?.setVolume(queue.volume / 100);

    queue.player.play(resource);

    queue.textChannel?.send({
      embeds: [
        songEmbed(
          "🎶 กำลังเล่น",
          `**[${song.title}](${song.url})**\nความยาว: \`${song.duration}\`\nขอโดย: ${song.requestedBy}`,
          0x57f287
        ),
      ],
    });
  } catch (err) {
    console.error("Error playing song:", err);
    queue.textChannel?.send({
      embeds: [
        songEmbed(
          "❌ เกิดข้อผิดพลาด",
          `ไม่สามารถเล่นเพลง **${song.title}** ได้\n\`${err.message}\``,
          0xed4245
        ),
      ],
    });
    queue.songs.shift();
    playSong(guild, queue);
  }
}

// ---------- Bot Ready ----------
client.once("ready", () => {
  console.log(`✅ Bot พร้อมใช้งาน! Logged in as ${client.user.tag}`);
  client.user.setActivity("!help | 🎵 Music Bot", { type: 2 }); // type 2 = Listening
});

// ---------- Message Handler ----------
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith(PREFIX)) return;
  if (!message.guild) return;

  const args = message.content.slice(PREFIX.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  // ==================== !play ====================
  if (command === "play" || command === "p") {
    const query = args.join(" ");
    if (!query) {
      return message.reply({
        embeds: [
          songEmbed(
            "❗ กรุณาใส่ชื่อเพลงหรือ URL",
            "ตัวอย่าง: `!play ชื่อเพลง` หรือ `!play https://youtube.com/...`",
            0xfee75c
          ),
        ],
      });
    }

    const voiceChannel = message.member.voice.channel;
    if (!voiceChannel) {
      return message.reply({
        embeds: [
          songEmbed(
            "❗ เข้าห้องเสียงก่อนนะ!",
            "คุณต้องอยู่ใน Voice Channel ก่อนจึงจะใช้คำสั่งนี้ได้",
            0xfee75c
          ),
        ],
      });
    }

    const queue = getQueue(message.guild.id);
    queue.textChannel = message.channel;

    // ค้นหาเพลง
    let songInfo;
    try {
      let searchResult;

      if (play.yt_validate(query) === "video") {
        // ถ้าเป็น YouTube URL
        const info = await play.video_info(query);
        searchResult = info.video_details;
      } else {
        // ค้นหาจากชื่อ
        const results = await play.search(query, { limit: 1 });
        if (!results || results.length === 0) {
          return message.reply({
            embeds: [
              songEmbed("❌ ไม่พบเพลง", `ไม่พบผลลัพธ์สำหรับ: \`${query}\``, 0xed4245),
            ],
          });
        }
        searchResult = results[0];
      }

      songInfo = {
        title: searchResult.title,
        url: searchResult.url,
        duration: searchResult.durationRaw || "N/A",
        thumbnail: searchResult.thumbnails?.[0]?.url || null,
        requestedBy: message.author.toString(),
      };
    } catch (err) {
      console.error("Search error:", err);
      return message.reply({
        embeds: [
          songEmbed("❌ ค้นหาไม่สำเร็จ", `\`${err.message}\``, 0xed4245),
        ],
      });
    }

    queue.songs.push(songInfo);

    // ถ้ายังไม่ได้เชื่อมต่อ voice channel
    if (!queue.connection) {
      try {
        const connection = joinVoiceChannel({
          channelId: voiceChannel.id,
          guildId: message.guild.id,
          adapterCreator: message.guild.voiceAdapterCreator,
        });

        const player = createAudioPlayer();

        player.on(AudioPlayerStatus.Idle, () => {
          queue.songs.shift();
          playSong(message.guild, queue);
        });

        player.on("error", (err) => {
          console.error("Player error:", err);
          queue.songs.shift();
          playSong(message.guild, queue);
        });

        connection.subscribe(player);
        queue.connection = connection;
        queue.player = player;

        // เริ่มเล่นเพลงแรก
        playSong(message.guild, queue);
      } catch (err) {
        console.error("Connection error:", err);
        queues.delete(message.guild.id);
        return message.reply({
          embeds: [
            songEmbed("❌ เชื่อมต่อไม่ได้", `\`${err.message}\``, 0xed4245),
          ],
        });
      }
    } else {
      // เพิ่มเข้าคิว
      message.channel.send({
        embeds: [
          songEmbed(
            "📋 เพิ่มเข้าคิวแล้ว",
            `**[${songInfo.title}](${songInfo.url})**\nลำดับที่: \`#${queue.songs.length}\`\nขอโดย: ${songInfo.requestedBy}`,
            0x5865f2
          ),
        ],
      });
    }
  }

  // ==================== !skip ====================
  else if (command === "skip" || command === "s") {
    const queue = queues.get(message.guild.id);
    if (!queue || !queue.playing) {
      return message.reply({
        embeds: [songEmbed("❗", "ไม่มีเพลงที่กำลังเล่นอยู่", 0xfee75c)],
      });
    }
    message.channel.send({
      embeds: [songEmbed("⏭️ ข้ามเพลง", `ข้ามเพลง **${queue.songs[0]?.title}**`, 0x5865f2)],
    });
    queue.player.stop();
  }

  // ==================== !stop ====================
  else if (command === "stop" || command === "leave" || command === "dc") {
    const queue = queues.get(message.guild.id);
    if (!queue) {
      return message.reply({
        embeds: [songEmbed("❗", "บอทไม่ได้อยู่ใน Voice Channel", 0xfee75c)],
      });
    }
    queue.songs = [];
    queue.player?.stop();
    queue.connection?.destroy();
    queues.delete(message.guild.id);
    message.channel.send({
      embeds: [songEmbed("👋 ออกจากห้องแล้ว", "หยุดเล่นเพลงและออกจาก Voice Channel", 0xed4245)],
    });
  }

  // ==================== !queue ====================
  else if (command === "queue" || command === "q") {
    const queue = queues.get(message.guild.id);
    if (!queue || queue.songs.length === 0) {
      return message.reply({
        embeds: [songEmbed("📋 คิวเพลง", "คิวว่างเปล่า ใช้ `!play` เพื่อเพิ่มเพลง", 0xfee75c)],
      });
    }
    const songList = queue.songs
      .map((s, i) => {
        const prefix = i === 0 ? "▶️ กำลังเล่น" : `${i}.`;
        return `${prefix} **${s.title}** [\`${s.duration}\`]`;
      })
      .slice(0, 15)
      .join("\n");

    const remaining = queue.songs.length > 15 ? `\n...และอีก ${queue.songs.length - 15} เพลง` : "";

    message.channel.send({
      embeds: [
        songEmbed("📋 คิวเพลง", `${songList}${remaining}\n\n**ทั้งหมด ${queue.songs.length} เพลง**`, 0x5865f2),
      ],
    });
  }

  // ==================== !pause ====================
  else if (command === "pause") {
    const queue = queues.get(message.guild.id);
    if (!queue || !queue.playing) {
      return message.reply({
        embeds: [songEmbed("❗", "ไม่มีเพลงที่กำลังเล่นอยู่", 0xfee75c)],
      });
    }
    queue.player.pause();
    message.channel.send({
      embeds: [songEmbed("⏸️ หยุดชั่วคราว", "ใช้ `!resume` เพื่อเล่นต่อ", 0xfee75c)],
    });
  }

  // ==================== !resume ====================
  else if (command === "resume") {
    const queue = queues.get(message.guild.id);
    if (!queue) {
      return message.reply({
        embeds: [songEmbed("❗", "ไม่มีเพลงในคิว", 0xfee75c)],
      });
    }
    queue.player.unpause();
    message.channel.send({
      embeds: [songEmbed("▶️ เล่นต่อ", `กำลังเล่น **${queue.songs[0]?.title}**`, 0x57f287)],
    });
  }

  // ==================== !np (Now Playing) ====================
  else if (command === "np" || command === "nowplaying") {
    const queue = queues.get(message.guild.id);
    if (!queue || queue.songs.length === 0) {
      return message.reply({
        embeds: [songEmbed("❗", "ไม่มีเพลงที่กำลังเล่นอยู่", 0xfee75c)],
      });
    }
    const song = queue.songs[0];
    message.channel.send({
      embeds: [
        songEmbed(
          "🎵 กำลังเล่นอยู่ตอนนี้",
          `**[${song.title}](${song.url})**\nความยาว: \`${song.duration}\`\nขอโดย: ${song.requestedBy}\n🔊 Volume: \`${queue.volume}%\``,
          0x57f287
        ),
      ],
    });
  }

  // ==================== !volume ====================
  else if (command === "volume" || command === "vol" || command === "v") {
    const queue = queues.get(message.guild.id);
    if (!queue || !queue.playing) {
      return message.reply({
        embeds: [songEmbed("❗", "ไม่มีเพลงที่กำลังเล่นอยู่", 0xfee75c)],
      });
    }

    const vol = parseInt(args[0]);
    if (isNaN(vol) || vol < 0 || vol > 100) {
      return message.reply({
        embeds: [
          songEmbed("❗", `Volume ปัจจุบัน: \`${queue.volume}%\`\nใช้ \`!volume 0-100\` เพื่อปรับ`, 0xfee75c),
        ],
      });
    }

    queue.volume = vol;
    // Volume จะมีผลกับเพลงถัดไป (resource ปัจจุบันไม่สามารถเปลี่ยนได้ง่าย)
    message.channel.send({
      embeds: [songEmbed("🔊 ปรับเสียง", `Volume: \`${vol}%\``, 0x5865f2)],
    });
  }

  // ==================== !help ====================
  else if (command === "help" || command === "h") {
    const helpText = [
      "`!play <ชื่อ/URL>` — เล่นเพลงหรือเพิ่มเข้าคิว",
      "`!skip` — ข้ามเพลงปัจจุบัน",
      "`!stop` — หยุดเล่นและออกจากห้อง",
      "`!queue` — ดูคิวเพลงทั้งหมด",
      "`!pause` — หยุดชั่วคราว",
      "`!resume` — เล่นต่อ",
      "`!np` — ดูเพลงที่กำลังเล่น",
      "`!volume <0-100>` — ปรับระดับเสียง",
      "`!help` — แสดงคำสั่งทั้งหมด",
    ].join("\n");

    message.channel.send({
      embeds: [songEmbed("🎵 Music Bot — คำสั่งทั้งหมด", helpText, 0x5865f2)],
    });
  }
});

// ---------- Login ----------
if (!TOKEN) {
  console.error("❌ กรุณาตั้งค่า DISCORD_TOKEN ก่อน!");
  console.error("   วิธี: DISCORD_TOKEN=your_token_here node index.js");
  process.exit(1);
}

client.login(TOKEN);
